package com.example.ctfapp

class SecurityManager {
    external fun isFridaDetected(): Boolean
    external fun validatePIN(pin: String): Boolean
}
